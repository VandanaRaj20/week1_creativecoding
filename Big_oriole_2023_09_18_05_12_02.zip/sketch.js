function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  
  
  fill('black')
  noStroke()
  ellipse(200,150,170,200)
  
  fill('#e0b275')
  
  ellipse(200,200,150,200)
  
  fill('#e0b275')
  ellipse(120,200,30,50)
  ellipse(280,200,30,50)
  
  fill('#c79d65')
  ellipse(200,210,30,30)
  
  fill('#FFFFFF')
  ellipse(165,165,30,30)
  ellipse(235,165,30,30)
  
  fill('black')
  ellipse(165,165,15,15)
  
  fill('black')
  ellipse(235,165,15,15)
  
  fill(200,100,100)
  rect(125,300, 150,100)
  
  line(30,0,30,400)
  line(370,0,370,400)
  
  fill('#A251FA')
  triangle(125,300,275,300,200,400)
  
  //nofill() gives only the stroke of the arc 
  fill('pink')
  noStroke()
  arc(200,240,100,50,0,PI)
  
}